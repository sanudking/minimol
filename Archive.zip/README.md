# MiniMoL — P2P Mobile Mesh Inference (QR pairing)

A browser-only two-phone implementation of the fixed seed-42, 6-layer, 11,040,768-parameter byte-level causal Transformer. Phone 1 owns embeddings + layers 0–2; Phone 2 owns layers 3–5 + final norm + output head.

## Included

- Full application source, including `src/inference-worker.js` and the CPU inference engine.
- QR-based WebRTC signaling: Phone 1 displays an offer QR; Phone 2 scans it and displays an answer QR; Phone 1 scans the answer. No SDP copy/paste.
- STUN-assisted ICE discovery; no TURN server and no signaling backend.
- JavaScript FP32 inference in dedicated Web Workers (CPU only; no WebGPU/WebGL).
- Binary activation frames over an ordered WebRTC DataChannel, chunked into 16 KiB messages.
- Role + model-fingerprint handshake and SHA-256 partition verification.
- IndexedDB partition persistence and a service worker for offline app-shell reloads.
- `models/manifest.json`, `models/phone1.bin`, `models/phone2.bin`, and `models/reference_outputs.json`.

The full unsplit `weights.bin`, any `weights/` directory, `dust/`, `node_modules/`, and generated `dist/` are intentionally not included. The two partition files are required runtime model artifacts and are included.

## Requirements

- Node.js 20 or newer.
- Current Safari on iPhone or Chrome on Android.
- HTTPS hosting for camera access, service workers, and WebRTC.
- Same Wi-Fi/LAN is recommended. Guest Wi-Fi/client isolation can block direct connections.

## Install, verify, and build

From the extracted project root (the directory containing `package.json`):

```bash
npm install
npm run verify
npm run build
```

`npm install` installs Vite plus the QR libraries (`qrcode` and `jsqr`) and creates the local lockfile. The build writes the deployable site to `dist/` and copies the two phone partitions into `dist/models/`.

Optional local preview:

```bash
npm run preview -- --host 0.0.0.0
```

## Two-phone setup

1. Deploy the contents of `dist/` to an HTTPS static host (Netlify or Vercel).
2. Open the same HTTPS URL on both phones.
3. Select Phone 1 on one device and Phone 2 on the other.
4. Tap **Load / restore weights** on each phone. Each phone loads only its own partition and verifies its SHA-256 hash.
5. On Phone 1, tap **Create offer QR** and keep the QR visible.
6. On Phone 2, tap **Scan peer QR** and scan Phone 1's QR. Phone 2 then displays its answer QR.
7. On Phone 1, tap **Scan answer QR** and scan Phone 2's QR.
8. Wait for **CONNECTED** on both devices. Start generation from Phone 1.

Pairing QR codes contain compressed WebRTC session descriptions, not model weights or inference activations. Exchange them only with the intended peer. The QR exchange replaces manual SDP copy/paste; after pairing, activations and byte IDs travel directly over the WebRTC DataChannel.

## Network limitations

The app uses public STUN servers for ICE address discovery, but does not configure TURN or a signaling relay. STUN does not guarantee connectivity through every NAT, firewall, carrier network, or Wi-Fi access point. Same-LAN direct connectivity is the preferred test setup. If ICE fails, try the same non-guest Wi-Fi, check AP/client isolation, and recreate both QR codes. Adding TURN would relay traffic and would change the strict direct-device-transfer design.

## Offline behavior

After the first successful HTTPS load, the service worker caches the app shell and JavaScript/CSS/worker assets. Each phone stores its own model partition in IndexedDB. The phones still need a working direct local network path to communicate with each other. Browser storage can be evicted by the operating system.

## Validation

```bash
npm run verify
```

This runs the split JS inference engine in Node against `models/reference_outputs.json` and checks the known 32-byte fixture. It validates the CPU inference path and model partitions, not real-device WebRTC connectivity or camera scanning. A physical two-phone test is still required.

## Model limitation

The included parameters are deterministic seed-42 initializations, not trained language-model weights. The network performs the specified Transformer computations, but it is not trained to generate meaningful English. Random byte outputs are expected until a trained checkpoint is exported into the same partition format.

## Architecture

```text
Phone 1 Web Worker                     Phone 2 Web Worker
embeddings + blocks 0–2                blocks 3–5 + norm + output head
       |                                           ^
       | FP32 hidden activation                   | FP32 hidden activation
       +------------- WebRTC DataChannel ----------+
                                                   |
       <--------------- greedy byte ID ------------+
```

Weights remain on their assigned phone. Only activations and token IDs cross the peer link. The complete `weights.bin` is not shipped to the browser app.
